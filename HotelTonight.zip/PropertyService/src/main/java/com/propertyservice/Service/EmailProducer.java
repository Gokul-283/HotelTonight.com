package com.propertyservice.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.propertyservice.Dto.EmailRequestDto;

@Service
public class EmailProducer {

    @Autowired
    private KafkaTemplate<String, EmailRequestDto> kafkaTemplate;

    private static final String TOPIC = "send_email";

    public void sendEmail(EmailRequestDto request) {
        kafkaTemplate.send(TOPIC, request);
    }
}