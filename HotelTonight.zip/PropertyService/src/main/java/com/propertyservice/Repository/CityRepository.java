package com.propertyservice.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.propertyservice.Entity.Area;
import com.propertyservice.Entity.City;
import com.propertyservice.Entity.Country;

public interface CityRepository extends JpaRepository<City, Long> {
	City findByName(String name);
}
