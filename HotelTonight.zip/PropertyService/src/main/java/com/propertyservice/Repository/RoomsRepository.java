package com.propertyservice.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.propertyservice.Entity.Rooms;

public interface RoomsRepository extends JpaRepository<Rooms, Long> {
	
	
	
	
	
	

}
