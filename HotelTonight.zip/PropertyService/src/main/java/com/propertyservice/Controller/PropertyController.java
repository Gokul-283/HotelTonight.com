package com.propertyservice.Controller;

import java.time.LocalDate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.propertyservice.Dto.ApiResponse;
import com.propertyservice.Dto.PropertyDto;
import com.propertyservice.Entity.Property;
import com.propertyservice.Entity.RoomAvailability;
import com.propertyservice.Entity.Rooms;
import com.propertyservice.Repository.RoomAvailabilityRepository;
import com.propertyservice.Service.PropertyServiceLayer;



@RestController
@RequestMapping("/api/v1/property")
public class PropertyController {
@Autowired
	public PropertyServiceLayer propertyServiceLayer;
@Autowired
public RoomAvailabilityRepository roomAvailabilityRepository;

	
@PostMapping(
	    value = "/addproperty",
	    consumes = MediaType.MULTIPART_FORM_DATA_VALUE,  // Ensures the endpoint accepts multipart/form-data
	    produces = MediaType.APPLICATION_JSON_VALUE
	)
	public ResponseEntity<ApiResponse> responseguide(@RequestParam ("property") String propertyJson,
			@RequestParam ("files") MultipartFile[] files){
		
		ObjectMapper objectMapper = new ObjectMapper();
	    PropertyDto dto = null;
	    try {
	        dto = objectMapper.readValue(propertyJson, PropertyDto.class);  // Convert JSON string to PropertyDto
	    } catch (JsonProcessingException e) {
	       
	        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);  // Handle bad JSON
	    }

	    // Process the property and files
	    Property property = propertyServiceLayer.addProperty(dto, files);

	    // Create response object
	    ApiResponse<Property> response = new ApiResponse<>();
	    response.setMessage("Property added");
	    response.setStatuscode(201);
	    response.setData(property);

	    return new ResponseEntity<>(response, HttpStatus.CREATED);
	
	
}
@GetMapping("/search-property")
public ApiResponse searchProperty(
        @RequestParam String name,
        @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
    ApiResponse response = propertyServiceLayer.searchProperty(name, date);
    return response;
}

@GetMapping("/property-id")
public ApiResponse<PropertyDto> getPropertyById(@RequestParam long id){
	ApiResponse<PropertyDto> response = propertyServiceLayer.findPropertyById(id);
	return response;
}

@GetMapping("/room-available-room-id")
public ApiResponse<List<RoomAvailability>> getTotalRoomsAvailable(@RequestParam long id){
	List<RoomAvailability> totalRooms = propertyServiceLayer.getTotalRoomsAvailable(id);
	
	ApiResponse<List<RoomAvailability>> response = new ApiResponse<>();
    response.setMessage("Total rooms");
    response.setStatuscode(200);
    response.setData(totalRooms);
    return response;
}

@GetMapping("/room-id")
public ApiResponse<Rooms> getRoomType(@RequestParam long id){
	Rooms room = propertyServiceLayer.getRoomById(id);
	
	ApiResponse<Rooms> response = new ApiResponse<>();
    response.setMessage("Total rooms");
    response.setStatuscode(200);
    response.setData(room);
    return response;
}
@PutMapping("/updateRoomCount")
public ApiResponse<Boolean> updateRoomCount(@RequestParam long id, @RequestParam LocalDate date){
	ApiResponse<Boolean> response = new ApiResponse();
	RoomAvailability roomsAvailable = roomAvailabilityRepository.getRooms(id, date);
	int count = roomsAvailable.getAvailableCount();
	if (count>0) {
	roomsAvailable.setAvailableCount(count-1);
	response.setMessage("RoomCountUpdated");
	response.setStatuscode(200);
	response.setData(true);
	return response;
}else {
	response.setMessage("No Availability");
	response.setStatuscode(500);
	response.setData(true);
	return response;
}

}}
