package com.propertyservice.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.propertyservice.Dto.ApiResponse;
import com.propertyservice.Dto.EmailRequestDto;
import com.propertyservice.Dto.PropertyDto;
import com.propertyservice.Dto.RoomsDto;
import com.propertyservice.Entity.Area;
import com.propertyservice.Entity.City;
import com.propertyservice.Entity.Country;
import com.propertyservice.Entity.Property;
import com.propertyservice.Entity.PropertyPhotos;
import com.propertyservice.Entity.RoomAvailability;
import com.propertyservice.Entity.Rooms;
import com.propertyservice.Entity.State;
import com.propertyservice.Repository.AreaRepository;
import com.propertyservice.Repository.CityRepository;
import com.propertyservice.Repository.CountryRepository;
import com.propertyservice.Repository.PropertyPhotosRepository;
import com.propertyservice.Repository.PropertyRepository;
import com.propertyservice.Repository.RoomAvailabilityRepository;
import com.propertyservice.Repository.RoomsRepository;
import com.propertyservice.Repository.StateRepository;

@Service
public class PropertyServiceLayer {
	
		@Autowired
		private PropertyRepository propertyRepository;
		@Autowired
		private AreaRepository areaRepository;
		@Autowired
		private CityRepository cityRepository;
		@Autowired
		private StateRepository stateRepository;
		@Autowired
		private CountryRepository countryRepository;
		@Autowired
		private RoomsRepository roomsRepository;
		@Autowired
		private RoomAvailabilityRepository availabilityRepository;
		@Autowired
		private S3Service s3Service;
		@Autowired
		private PropertyPhotosRepository propertyPhotosRepository;
		@Autowired
		private EmailProducer emailProducer;
		
		
	

	public Property addProperty(PropertyDto dto, MultipartFile[] files) {
		 Area area = areaRepository.findByName(dto.getArea());
		    City city = cityRepository.findByName(dto.getCity());
		    State state = stateRepository.findByName(dto.getState());
		    Country country = countryRepository.findByName(dto.getCountry());

		    Property property = new Property();
		    property.setName(dto.getName());
		    property.setNumberOfBathrooms(dto.getNumberOfBathrooms());
		    property.setNumberOfBeds(dto.getNumberOfBeds());
		    property.setNumberOfRooms(dto.getNumberOfRooms());
		    property.setNumberOfGuestAllowed(dto.getNumberOfGuestAllowed());
		    property.setArea(area);
		    property.setCity(city);
		    property.setState(state);
		    property.setCountry(country);
		  
		    Property savedProperty = propertyRepository.save(property);
		  // Save rooms
	    for (RoomsDto roomsDto : dto.getRooms()) {
	        Rooms rooms = new Rooms();
	        rooms.setProperty(savedProperty);
	        rooms.setRoomType(roomsDto.getRoomType());
	        rooms.setBaseprice(roomsDto.getBaseprice());
	        roomsRepository.save(rooms);
	    }

	    // Upload files to S3
	    List<String> fileUrls = s3Service.uploadFiles(files);
	    for(String url: fileUrls) {
	    	PropertyPhotos photo  = new PropertyPhotos();
	    	photo.setUrl(url);
	    	photo.setProperty(savedProperty);
	    	propertyPhotosRepository.save(photo);
	    }
	    
	    
	    emailProducer.sendEmail(new EmailRequestDto(
	    	    "pankaj.p.mutha14@gmail.com",
	    	    "Property added!",
	    	    "Your property has been successfully added."
	    	));
	    
	    
	    
	    return savedProperty;
	
	    
	    
	}




	public ApiResponse searchProperty(String name, LocalDate date) {
		List<Property> properties = propertyRepository.searchProperty(name,date);
		ApiResponse<List<Property>> response = new ApiResponse<>();
		
		response.setMessage("Search result");
		response.setStatuscode(200);
		response.setData(properties);
		
		return response;
	}
	
	public ApiResponse<PropertyDto> findPropertyById(long id){
		ApiResponse<PropertyDto> response = new ApiResponse<>();
		PropertyDto dto  = new PropertyDto();
		Optional<Property> opProp = propertyRepository.findById(id);
		if(opProp.isPresent()) {
			Property property = opProp.get();
			dto.setArea(property.getArea().getName());
			dto.setCity(property.getCity().getName());
			dto.setState(property.getState().getName());
			List<Rooms> rooms = property.getRooms();
			List<RoomsDto> roomsDto = new ArrayList<>();
			for(Rooms room:rooms) {
				RoomsDto roomDto = new RoomsDto();
				BeanUtils.copyProperties(room, roomDto);
				roomsDto.add(roomDto);
			}
			dto.setRooms(roomsDto);
			BeanUtils.copyProperties(property, dto);
			response.setMessage("Matching Record");
			response.setStatuscode(200);
			response.setData(dto);
			return response;
		}
		
		return null;
	}

	public List<RoomAvailability> getTotalRoomsAvailable(long id) {
		return availabilityRepository.findByRoomId(id);
		
	}
	
	public Rooms getRoomById(long id) {
		return roomsRepository.findById(id).get();
	}
	
	
	

}
