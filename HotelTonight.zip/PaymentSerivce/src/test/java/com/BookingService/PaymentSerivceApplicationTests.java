package com.BookingService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentSerivceApplicationTests {

	@Test
	void contextLoads() {
	}

}
