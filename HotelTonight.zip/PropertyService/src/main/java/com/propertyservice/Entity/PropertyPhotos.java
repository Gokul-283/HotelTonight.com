package com.propertyservice.Entity;

import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.persistence.*;

@Entity
@RequestMapping("/api/v1/upload-photo")
public class PropertyPhotos {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String url;
	
	@ManyToOne
	@JoinColumn(name = "propert_id")
	
	private Property property;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Property getProperty() {
		return property;
	}

	public void setProperty(Property property) {
		this.property = property;
	}
}
